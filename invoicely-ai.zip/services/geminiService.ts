
import { GoogleGenAI, Type } from "@google/genai";
import { Invoice, InvoiceStatus } from "../types";
import { Language } from "../translations";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const geminiService = {
  /**
   * Generates a structured invoice from natural language description.
   */
  async generateInvoiceFromText(prompt: string, lang: Language = 'en'): Promise<Partial<Invoice>> {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Parse the following business transaction details into a structured invoice format. The user is currently using the UI in ${lang === 'ar' ? 'Arabic' : 'English'}. Please ensure descriptions match this language where appropriate: "${prompt}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            invoice_number: { type: Type.STRING },
            date: { type: Type.STRING },
            due_date: { type: Type.STRING },
            customer: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                email: { type: Type.STRING },
                address: { type: Type.STRING }
              }
            },
            items: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  description: { type: Type.STRING },
                  quantity: { type: Type.NUMBER },
                  unit_price: { type: Type.NUMBER }
                }
              }
            },
            notes: { type: Type.STRING }
          },
          required: ["items"]
        }
      }
    });

    try {
      return JSON.parse(response.text || "{}");
    } catch (e) {
      console.error("Failed to parse Gemini response", e);
      return {};
    }
  },

  /**
   * Analyzes invoice trends and provides business advice.
   */
  async getBusinessInsights(invoices: Invoice[]): Promise<string> {
    const invoiceSummary = invoices.map(i => ({
      amount: i.total_amount,
      status: i.status,
      date: i.date
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze these invoice records and provide 3 short, actionable business insights: ${JSON.stringify(invoiceSummary)}`,
    });

    return response.text || "No insights available at this time.";
  }
};
