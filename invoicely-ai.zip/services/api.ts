
import { Invoice, InvoiceStatus, Customer, Company } from "../types";

// Simulated database
let invoices: Invoice[] = [
  {
    id: '1',
    invoice_number: 'INV-2024-001',
    date: '2024-05-10',
    due_date: '2024-06-10',
    status: InvoiceStatus.PAID,
    company_id: 'COMP-1',
    customer_id: 'CUST-1',
    items: [
      { id: 'item1', description: 'Web Design Project', quantity: 1, unit_price: 2500, total: 2500 },
      { id: 'item2', description: 'Hosting (Annual)', quantity: 1, unit_price: 300, total: 300 }
    ],
    subtotal: 2800,
    tax_rate: 10,
    tax_total: 280,
    total_amount: 3080,
    notes: 'Thanks for your business!'
  },
  {
    id: '2',
    invoice_number: 'INV-2024-002',
    date: '2024-05-15',
    due_date: '2024-06-15',
    status: InvoiceStatus.SENT,
    company_id: 'COMP-1',
    customer_id: 'CUST-2',
    items: [
      { id: 'item3', description: 'Consulting Hours', quantity: 10, unit_price: 150, total: 1500 }
    ],
    subtotal: 1500,
    tax_rate: 10,
    tax_total: 150,
    total_amount: 1650
  }
];

export const api = {
  getInvoices: async (): Promise<Invoice[]> => {
    return [...invoices];
  },

  createInvoice: async (data: Partial<Invoice>): Promise<Invoice> => {
    const newInvoice: Invoice = {
      ...data as Invoice,
      id: Math.random().toString(36).substr(2, 9),
      status: data.status || InvoiceStatus.DRAFT,
    };
    invoices = [newInvoice, ...invoices];
    return newInvoice;
  },

  getCustomers: async (): Promise<Customer[]> => {
    return [
      { id: 'CUST-1', name: 'ABC Corp', email: 'billing@abccorp.com', address: '123 Tech Lane', phone: '555-0192' },
      { id: 'CUST-2', name: 'Design Labs', email: 'hello@designlabs.io', address: '456 creative Ave', phone: '555-0123' }
    ];
  },

  getCompany: async (): Promise<Company> => {
    return {
      id: 'COMP-1',
      name: 'My Digital Agency',
      email: 'finance@mydigital.com',
      address: '789 Business Blvd',
      phone: '555-9999'
    };
  }
};
