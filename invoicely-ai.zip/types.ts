
export enum InvoiceStatus {
  DRAFT = 'draft',
  SENT = 'sent',
  PAID = 'paid',
  OVERDUE = 'overdue'
}

export interface Company {
  id: string;
  name: string;
  email: string;
  address: string;
  phone: string;
  logo?: string;
  tax_id?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  address: string;
  phone: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unit_price: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  date: string;
  due_date: string;
  status: InvoiceStatus;
  company_id: string;
  customer_id: string;
  items: InvoiceItem[];
  subtotal: number;
  tax_rate: number;
  tax_total: number;
  total_amount: number;
  notes?: string;
}

export interface DashboardStats {
  totalRevenue: number;
  pendingAmount: number;
  paidCount: number;
  overdueCount: number;
}
