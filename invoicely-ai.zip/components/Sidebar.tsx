
import React from 'react';
import { translations, Language } from '../translations';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lang: Language;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, lang }) => {
  const t = translations[lang];
  const menuItems = [
    { id: 'dashboard', label: t.dashboard, icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { id: 'invoices', label: t.invoices, icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
    { id: 'customers', label: t.customers, icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z' },
    { id: 'ai-genius', label: t.aiStudio, icon: 'M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0012 18.75c-1.03 0-1.9-.4-2.593-.903l-.547-.547z' },
  ];

  return (
    <div className="hidden md:flex flex-col w-72 bg-white border-x border-gray-100 h-screen sticky top-0">
      <div className="flex items-center px-8 h-20 border-b border-gray-50">
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <div className="w-10 h-10 bg-gradient-to-tr from-indigo-600 to-indigo-400 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-100 transform -rotate-3 hover:rotate-0 transition-transform cursor-pointer">
            <span className="text-white font-black text-2xl tracking-tighter">I</span>
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-black text-gray-900 leading-none tracking-tight">INVOICELY</span>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none mt-1">Intelligent Biz</span>
          </div>
        </div>
      </div>
      
      <div className="mt-8 px-4 flex-1">
        <div className="mb-4 px-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">{lang === 'ar' ? 'القائمة الرئيسية' : 'Main Menu'}</div>
        <nav className="space-y-1">
            {menuItems.map((item) => (
            <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center px-4 py-3 rounded-xl transition-all duration-300 group ${
                activeTab === item.id
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
                }`}
            >
                <div className={`p-1.5 rounded-lg mx-3 transition-colors ${
                    activeTab === item.id ? 'bg-indigo-500' : 'bg-gray-50 group-hover:bg-gray-100'
                }`}>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={item.icon} />
                    </svg>
                </div>
                <span className="font-bold text-sm">{item.label}</span>
            </button>
            ))}
        </nav>
      </div>

      <div className="p-6">
        <div className="bg-gray-50 rounded-2xl p-4 flex items-center space-x-3 rtl:space-x-reverse border border-gray-100 group cursor-pointer hover:bg-white hover:shadow-xl hover:shadow-gray-100 transition-all duration-300">
          <img className="h-10 w-10 rounded-xl bg-gray-200 border-2 border-white shadow-sm" src="https://picsum.photos/100/100?random=1" alt="Profile" />
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-black text-gray-900 truncate">John Doe</p>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tight">{t.admin}</p>
          </div>
          <svg className="w-4 h-4 text-gray-400 group-hover:text-indigo-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
