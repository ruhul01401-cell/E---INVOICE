
import React from 'react';
import { Invoice, InvoiceStatus } from '../types';
import { translations, Language } from '../translations';

interface InvoiceTableProps {
  invoices: Invoice[];
  onView: (id: string) => void;
  lang: Language;
}

const InvoiceTable: React.FC<InvoiceTableProps> = ({ invoices, onView, lang }) => {
  const t = translations[lang];

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      <table className="w-full text-left rtl:text-right">
        <thead>
          <tr className="bg-gray-50 text-gray-500 text-xs font-semibold uppercase tracking-wider">
            <th className="px-6 py-4 border-b border-gray-100">{t.invoiceNumber}</th>
            <th className="px-6 py-4 border-b border-gray-100">{t.date}</th>
            <th className="px-6 py-4 border-b border-gray-100">{t.amount}</th>
            <th className="px-6 py-4 border-b border-gray-100">{t.status}</th>
            <th className="px-6 py-4 border-b border-gray-100 text-right rtl:text-left">{t.actions}</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {invoices.length === 0 ? (
            <tr>
              <td colSpan={5} className="px-6 py-10 text-center text-gray-500 italic">{t.noInvoices}</td>
            </tr>
          ) : (
            invoices.map(inv => (
              <tr key={inv.id} className="hover:bg-gray-50 group transition-colors">
                <td className="px-6 py-4 font-medium text-gray-900">{inv.invoice_number}</td>
                <td className="px-6 py-4 text-gray-600">{inv.date}</td>
                <td className="px-6 py-4 font-bold text-gray-900">${inv.total_amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold ring-1 ring-inset ${
                    inv.status === InvoiceStatus.PAID ? 'bg-green-50 text-green-700 ring-green-600/20' : 
                    inv.status === InvoiceStatus.SENT ? 'bg-blue-50 text-blue-700 ring-blue-600/20' : 
                    inv.status === InvoiceStatus.OVERDUE ? 'bg-red-50 text-red-700 ring-red-600/20' : 
                    'bg-gray-50 text-gray-700 ring-gray-600/20'
                  }`}>
                    {lang === 'ar' ? (inv.status === InvoiceStatus.PAID ? 'مدفوع' : 'مرسل') : inv.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right rtl:text-left">
                  <button 
                    onClick={() => onView(inv.id)}
                    className="text-gray-400 hover:text-indigo-600 font-medium text-sm transition-colors"
                  >
                    {t.viewDetails}
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default InvoiceTable;
