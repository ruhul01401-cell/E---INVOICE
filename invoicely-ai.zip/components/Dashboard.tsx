// This file is deprecated in favor of pages/Dashboard.tsx
import Dashboard from '../pages/Dashboard';
export default Dashboard;
