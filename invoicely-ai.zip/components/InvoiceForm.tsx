
import React, { useState } from 'react';
import { Invoice, InvoiceItem, InvoiceStatus } from '../types';
import { translations, Language } from '../translations';

interface InvoiceFormProps {
  initialData?: Partial<Invoice>;
  onSave: (invoice: Partial<Invoice>) => void;
  onCancel: () => void;
  lang: Language;
}

const InvoiceForm: React.FC<InvoiceFormProps> = ({ initialData, onSave, onCancel, lang }) => {
  const t = translations[lang];
  const [formData, setFormData] = useState<Partial<Invoice>>({
    invoice_number: initialData?.invoice_number || `INV-${Math.floor(Math.random() * 10000)}`,
    date: initialData?.date || new Date().toISOString().split('T')[0],
    due_date: initialData?.due_date || '',
    status: initialData?.status || InvoiceStatus.DRAFT,
    items: initialData?.items || [],
    tax_rate: initialData?.tax_rate || 10,
    notes: initialData?.notes || '',
  });

  const addItem = () => {
    const newItem: InvoiceItem = {
      id: Math.random().toString(36).substr(2, 9),
      description: '',
      quantity: 1,
      unit_price: 0,
      total: 0
    };
    setFormData(prev => ({ ...prev, items: [...(prev.items || []), newItem] }));
  };

  const updateItem = (id: string, field: keyof InvoiceItem, value: any) => {
    setFormData(prev => {
      const updatedItems = (prev.items || []).map(item => {
        if (item.id === id) {
          const updated = { ...item, [field]: value };
          if (field === 'quantity' || field === 'unit_price') {
            updated.total = updated.quantity * updated.unit_price;
          }
          return updated;
        }
        return item;
      });
      return { ...prev, items: updatedItems };
    });
  };

  const removeItem = (id: string) => {
    setFormData(prev => ({
      ...prev,
      items: (prev.items || []).filter(i => i.id !== id)
    }));
  };

  const calculateTotals = () => {
    const subtotal = (formData.items || []).reduce((sum, item) => sum + item.total, 0);
    const taxTotal = subtotal * ((formData.tax_rate || 0) / 100);
    return { subtotal, taxTotal, total: subtotal + taxTotal };
  };

  const { subtotal, taxTotal, total } = calculateTotals();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      subtotal,
      tax_total: taxTotal,
      total_amount: total
    });
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-lg overflow-hidden max-w-4xl mx-auto rtl:text-right">
      <div className="p-6 border-b border-gray-200 bg-gray-50">
        <h2 className="text-xl font-bold text-gray-900">{t.createNew}</h2>
      </div>

      <form onSubmit={handleSubmit} className="p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">{t.invoiceNumber}</label>
            <input
              type="text"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              value={formData.invoice_number}
              onChange={e => setFormData(prev => ({ ...prev, invoice_number: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">{t.date}</label>
            <input
              type="date"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              value={formData.date}
              onChange={e => setFormData(prev => ({ ...prev, date: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">{lang === 'ar' ? 'تاريخ الاستحقاق' : 'Due Date'}</label>
            <input
              type="date"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              value={formData.due_date}
              onChange={e => setFormData(prev => ({ ...prev, due_date: e.target.value }))}
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">{t.billTo}</label>
          <input
            type="text"
            placeholder={lang === 'ar' ? 'اسم العميل أو البريد الإلكتروني' : 'Customer Name or Email'}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">{t.items}</h3>
            <button type="button" onClick={addItem} className="text-indigo-600 hover:text-indigo-700 text-sm font-medium flex items-center">
              <svg className="w-4 h-4 mx-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
              </svg>
              {t.addItem}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left rtl:text-right border-collapse">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-[10px] font-bold uppercase tracking-wider">
                  <th className="px-4 py-3 border-b">{t.description}</th>
                  <th className="px-4 py-3 border-b w-24">{t.qty}</th>
                  <th className="px-4 py-3 border-b w-32">{t.price}</th>
                  <th className="px-4 py-3 border-b w-32">{t.total}</th>
                  <th className="px-4 py-3 border-b w-10"></th>
                </tr>
              </thead>
              <tbody>
                {(formData.items || []).map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <input type="text" className="w-full bg-transparent border-none focus:ring-0 text-sm text-gray-900" value={item.description} onChange={e => updateItem(item.id, 'description', e.target.value)} />
                    </td>
                    <td className="px-4 py-3">
                      <input type="number" className="w-full bg-transparent border-none focus:ring-0 text-sm text-gray-900" value={item.quantity} onChange={e => updateItem(item.id, 'quantity', parseFloat(e.target.value))} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center">
                        <span className="text-gray-400 mx-1">$</span>
                        <input type="number" className="w-full bg-transparent border-none focus:ring-0 text-sm text-gray-900" value={item.unit_price} onChange={e => updateItem(item.id, 'unit_price', parseFloat(e.target.value))} />
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">
                      ${item.total.toFixed(2)}
                    </td>
                    <td className="px-4 py-3">
                      <button type="button" onClick={() => removeItem(item.id)} className="text-gray-400 hover:text-red-500">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8 border-t border-gray-200">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">{t.notes}</label>
            <textarea rows={4} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" value={formData.notes} onChange={e => setFormData(prev => ({ ...prev, notes: e.target.value }))} />
          </div>
          <div className="space-y-3 bg-gray-50 p-6 rounded-xl">
            <div className="flex justify-between text-sm text-gray-600">
              <span>{t.subtotal}</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-sm text-gray-600">
              <span>{t.taxRate}</span>
              <span>${taxTotal.toFixed(2)}</span>
            </div>
            <div className="pt-3 border-t border-gray-200 flex justify-between items-center text-xl font-bold text-gray-900">
              <span>{t.total}</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-4 rtl:space-x-reverse pt-6">
          <button type="button" onClick={onCancel} className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors">
            {t.cancel}
          </button>
          <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 shadow-md transition-colors">
            {t.saveInvoice}
          </button>
        </div>
      </form>
    </div>
  );
};

export default InvoiceForm;
