
import React, { useState } from 'react';
import { geminiService } from '../services/geminiService';
import { Invoice } from '../types';
import { translations, Language } from '../translations';

interface AIAssistantProps {
  onGenerated: (data: Partial<Invoice>) => void;
  lang: Language;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ onGenerated, lang }) => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const t = translations[lang];

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    try {
      const data = await geminiService.generateInvoiceFromText(prompt, lang);
      onGenerated(data);
      setPrompt('');
    } catch (error) {
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-indigo-600 rounded-3xl p-10 text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10">
          <h2 className="text-3xl font-extrabold mb-4">{t.aiDraftTitle}</h2>
          <p className="text-indigo-100 text-lg mb-8 max-w-md">
            {t.aiDraftSubtitle}
          </p>
          
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20">
            <textarea
              className="w-full bg-transparent border-none focus:ring-0 text-white placeholder-indigo-200 resize-none h-24 rtl:text-right"
              placeholder={t.aiPlaceholder}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
            <div className="flex justify-between items-center mt-2 rtl:flex-row-reverse">
              <span className="text-xs text-indigo-200">Gemini 3 Pro powered intelligence</span>
              <button
                disabled={isGenerating}
                onClick={handleGenerate}
                className="bg-white text-indigo-600 px-6 py-2 rounded-xl font-bold hover:bg-indigo-50 transition-colors shadow-lg disabled:opacity-50"
              >
                {isGenerating ? t.generating : t.generateButton}
              </button>
            </div>
          </div>
        </div>
        
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-indigo-500/30 rounded-full blur-3xl"></div>
      </div>
    </div>
  );
};

export default AIAssistant;
