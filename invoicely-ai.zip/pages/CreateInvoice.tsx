
import React, { useState } from 'react';
import InvoiceForm from '../components/InvoiceForm';
import AIAssistant from '../components/AIAssistant';
import { Invoice } from '../types';
import { translations, Language } from '../translations';

interface CreateInvoiceProps {
  onSave: (invoice: Partial<Invoice>) => void;
  onCancel: () => void;
  lang: Language;
}

const CreateInvoice: React.FC<CreateInvoiceProps> = ({ onSave, onCancel, lang }) => {
  const [draftData, setDraftData] = useState<Partial<Invoice> | null>(null);
  const [activeMethod, setActiveMethod] = useState<'manual' | 'ai'>('ai');
  const t = translations[lang];

  const handleAIDrafted = (data: Partial<Invoice>) => {
    setDraftData(data);
    setActiveMethod('manual');
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-gray-900">{t.createNew}</h2>
          <p className="text-gray-500">{lang === 'ar' ? 'اختر طريقتك المفضلة لإنشاء مستندات الفوترة.' : 'Choose your preferred way to generate billing documents.'}</p>
        </div>
        <div className="bg-gray-100 p-1 rounded-xl flex rtl:flex-row-reverse">
          <button 
            onClick={() => setActiveMethod('ai')}
            className={`px-4 py-2 text-sm font-bold rounded-lg transition-all ${activeMethod === 'ai' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            {t.aiGenerator}
          </button>
          <button 
            onClick={() => {
                setActiveMethod('manual');
                setDraftData(null);
            }}
            className={`px-4 py-2 text-sm font-bold rounded-lg transition-all ${activeMethod === 'manual' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            {t.manualEntry}
          </button>
        </div>
      </div>

      <div className="transition-all duration-300">
        {activeMethod === 'ai' ? (
          <AIAssistant onGenerated={handleAIDrafted} lang={lang} />
        ) : (
          <InvoiceForm 
            initialData={draftData || {}} 
            onSave={onSave} 
            onCancel={onCancel} 
            lang={lang}
          />
        )}
      </div>
    </div>
  );
};

export default CreateInvoice;
