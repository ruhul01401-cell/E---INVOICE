
import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Invoice, DashboardStats, InvoiceStatus } from '../types';
import { translations, Language } from '../translations';

interface DashboardProps {
  invoices: Invoice[];
  lang: Language;
}

const Dashboard: React.FC<DashboardProps> = ({ invoices, lang }) => {
  const t = translations[lang];
  const stats = useMemo<DashboardStats>(() => {
    return invoices.reduce((acc, inv) => {
      acc.totalRevenue += inv.status === InvoiceStatus.PAID ? inv.total_amount : 0;
      acc.pendingAmount += (inv.status === InvoiceStatus.SENT || inv.status === InvoiceStatus.DRAFT) ? inv.total_amount : 0;
      if (inv.status === InvoiceStatus.PAID) acc.paidCount++;
      if (inv.status === InvoiceStatus.OVERDUE) acc.overdueCount++;
      return acc;
    }, { totalRevenue: 0, pendingAmount: 0, paidCount: 0, overdueCount: 0 });
  }, [invoices]);

  const chartData = [
    { name: lang === 'ar' ? 'الإثنين' : 'Mon', revenue: 4000 },
    { name: lang === 'ar' ? 'الثلاثاء' : 'Tue', revenue: 3000 },
    { name: lang === 'ar' ? 'الأربعاء' : 'Wed', revenue: 5000 },
    { name: lang === 'ar' ? 'الخميس' : 'Thu', revenue: 2780 },
    { name: lang === 'ar' ? 'الجمعة' : 'Fri', revenue: 1890 },
    { name: lang === 'ar' ? 'السبت' : 'Sat', revenue: 2390 },
    { name: lang === 'ar' ? 'الأحد' : 'Sun', revenue: 3490 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title={t.totalRevenue} value={`$${stats.totalRevenue.toLocaleString()}`} change="+12.5%" />
        <StatCard title={t.pending} value={`$${stats.pendingAmount.toLocaleString()}`} change="+3.2%" />
        <StatCard title={t.paidInvoices} value={stats.paidCount.toString()} change="+8.1%" />
        <StatCard title={t.overdue} value={stats.overdueCount.toString()} change="-2.4%" isNegative />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-gray-900">{t.revenueTrends}</h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 10}} dy={10} reversed={lang === 'ar'} />
                <YAxis axisLine={false} orientation={lang === 'ar' ? 'right' : 'left'} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} tickFormatter={(v) => `$${v/1000}k`} />
                <Tooltip 
                  contentStyle={{backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e5e7eb', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                  itemStyle={{color: '#6366f1', fontWeight: 600}}
                />
                <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-6">{t.recentActivity}</h3>
          <div className="space-y-5">
            {invoices.slice(0, 5).map(inv => (
              <div key={inv.id} className="flex items-center justify-between border-b border-gray-50 pb-4 last:border-0 last:pb-0">
                <div className="flex items-center">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs ${
                    inv.status === InvoiceStatus.PAID ? 'bg-green-50 text-green-600' : 'bg-indigo-50 text-indigo-600'
                  }`}>
                    {inv.invoice_number.slice(-3)}
                  </div>
                  <div className="mx-3">
                    <p className="text-sm font-semibold text-gray-900">{t.invoiceNumber} {inv.invoice_number}</p>
                    <p className="text-xs text-gray-500">{inv.date}</p>
                  </div>
                </div>
                <div className="text-right rtl:text-left">
                  <p className="text-sm font-bold text-gray-900">${inv.total_amount.toFixed(2)}</p>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-bold uppercase ${
                    inv.status === InvoiceStatus.PAID ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {lang === 'ar' ? (inv.status === InvoiceStatus.PAID ? 'مدفوع' : 'مرسل') : inv.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, change, isNegative }: any) => {
  return (
    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:border-indigo-100 transition-colors">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">{title}</span>
        <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${isNegative ? 'text-red-600 bg-red-50' : 'text-green-600 bg-green-50'}`}>
          {change}
        </span>
      </div>
      <div className="flex items-baseline">
        <span className="text-2xl font-extrabold text-gray-900">{value}</span>
      </div>
    </div>
  );
};

export default Dashboard;
