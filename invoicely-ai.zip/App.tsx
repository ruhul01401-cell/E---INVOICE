
import React, { useState, useEffect } from 'react';
import { Invoice, InvoiceStatus } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import CreateInvoice from './pages/CreateInvoice';
import InvoiceTable from './components/InvoiceTable';
import { api } from './services/api';
import { translations, Language } from './translations';

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('en');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const t = translations[lang];

  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    const loadData = async () => {
      const data = await api.getInvoices();
      setInvoices(data);
      setIsLoading(false);
    };
    loadData();
  }, []);

  const handleSaveInvoice = async (data: Partial<Invoice>) => {
    const newInv = await api.createInvoice(data);
    setInvoices(prev => [newInv, ...prev]);
    setActiveTab('invoices');
  };

  const toggleLanguage = () => {
    setLang(prev => prev === 'en' ? 'ar' : 'en');
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      );
    }

    switch (activeTab) {
      case 'dashboard':
        return <Dashboard invoices={invoices} lang={lang} />;
      case 'invoices':
        return (
            <div className="space-y-4">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-gray-900">{t.invoices}</h2>
                    <div className="flex space-x-2 rtl:space-x-reverse">
                        <input 
                            type="text" 
                            placeholder={t.searchPlaceholder} 
                            className="text-sm px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none w-64"
                        />
                    </div>
                </div>
                <InvoiceTable invoices={invoices} onView={(id) => console.log('view', id)} lang={lang} />
            </div>
        );
      case 'ai-genius':
      case 'create-invoice':
        return <CreateInvoice onSave={handleSaveInvoice} onCancel={() => setActiveTab('invoices')} lang={lang} />;
      case 'customers':
        return (
          <div className="flex flex-col items-center justify-center py-20 text-center">
             <div className="w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center text-gray-400 mb-6 rotate-3 group-hover:rotate-0 transition-transform">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
             </div>
             <h3 className="text-xl font-bold text-gray-900">{t.customers}</h3>
             <p className="text-gray-500 max-w-sm mt-3">Import your client list from your CRM or add them individually to speed up billing.</p>
             <button className="mt-8 bg-white border border-gray-200 px-6 py-2 rounded-xl font-bold text-gray-700 hover:bg-gray-50 transition-colors shadow-sm">
                Connect External CRM
             </button>
          </div>
        );
      default:
        return <Dashboard invoices={invoices} lang={lang} />;
    }
  };

  return (
    <div className="flex h-screen bg-[#fcfcfd] overflow-hidden">
      <Sidebar activeTab={activeTab === 'create-invoice' ? 'ai-genius' : activeTab} setActiveTab={setActiveTab} lang={lang} />
      
      <main className="flex-1 overflow-y-auto relative">
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-gray-100 px-8 h-18 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-[0.2em]">Invoicely AI</span>
            <h1 className="text-lg font-extrabold text-gray-900 capitalize tracking-tight leading-none">
                {activeTab === 'create-invoice' ? t.createNew : t[activeTab as keyof typeof t] || activeTab}
            </h1>
          </div>
          
          <div className="flex items-center space-x-6 rtl:space-x-reverse">
            <button 
                onClick={toggleLanguage}
                className="text-xs font-bold px-3 py-1.5 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
                {lang === 'en' ? 'العربية' : 'English'}
            </button>

            <div className="hidden lg:flex items-center space-x-2 rtl:space-x-reverse px-3 py-1.5 bg-green-50 rounded-full border border-green-100">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                <span className="text-[10px] font-extrabold text-green-700 uppercase">{t.systemActive}</span>
            </div>
            
            <div className="h-6 w-px bg-gray-200"></div>

            <button 
              onClick={() => setActiveTab('create-invoice')}
              className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-md shadow-indigo-200 flex items-center transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <svg className="w-5 h-5 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4" />
              </svg>
              {t.createNew}
            </button>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;
